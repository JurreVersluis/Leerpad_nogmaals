number1 = 50
number2 = 0
maxnumber = 1000

while number2 < maxnumber:
    print(number2)
    number2 = number2 + number1
    number1 += 1
