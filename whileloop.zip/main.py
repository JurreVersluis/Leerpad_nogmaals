import time
seconden = 30
while seconden > 0:
    print(seconden)
    time.sleep(0.1)
    seconden -= 1
print("we zijn opgestegen!")