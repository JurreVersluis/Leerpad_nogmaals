getal1 = 20
while getal1 < 51:
    if getal1 % 2 == 0:
        print(getal1)
    getal1 += 1
